class DeepQuantError(Exception):
    def __int__(self, message):
        super(message)


class StrategyRobotError(Exception):
    def __int__(self, message):
        super(message)


class TradeRobotError(Exception):
    def __int__(self, message):
        super(message)


class TradeModelError(Exception):
    def __int__(self, message):
        super(message)


class PredictiveModelError(Exception):
    def __int__(self, message):
        super(message)


class DataProcessingError(Exception):
    def __int__(self, message):
        super(message)

