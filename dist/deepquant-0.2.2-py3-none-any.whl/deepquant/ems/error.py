
class ExecutionError(Exception):
    def __int__(self, message):
        super(message)
